import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.awt.Color; 
import org.aec.facade.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class rarah_v6 extends PApplet {

/* ---------------------------------------------------------------------------------------------------------------------------------------------------------
 WELCOME TO : STRESS BOX
 
 "With a surprise you see with your eyes"
 
 By Kira Martin and Sarah Chou (aka, Team RaRah)
 
 Our façade design was inspired by screensavers and the moving, bouncing DVD logo (see here: https://bouncingdvdlogo.com ). We created an emulation of that
 using rectangles on the windows of the Ars Electronica building. Each of the four walls has a different colored “ball” that “bounces” at a randomly chosen 
 velocity. The point of this project was to create a cycle of anticipation and gratification for when the ball aligns perfectly in a corner of the wall. Upon
 collision, a “celebration” happens creating a feeling of satisfaction. The cycle then repeats itself.  
 
 The concept is to take away the immediate gratification of an ‘action/output’ that so much of technology has today. A decade ago, DVD was the most common 
 way to watch movies. Technology was at the stage where users had to exercise patience when waiting for an action (such as fast forwarding or rewinding). 
 Patience is truly a virtue that is lost due to the decreased attention span of today’s generation. Technology responds so immediately to requests that the
 user no longer has to wait. When viewers are watching Stress Box, they may feel anxious when awaiting the ‘perfect collision’.  Each bounce off of the wall
 comes so close to the corner but misses it by a hair. When the celebration finally occurs, the viewer may finally feel fulfilled, only to immediately feel
 a loop of anticipation for future celebrations. 
 
 
 ---------------------------------------------------------------------------------------------------------------------------------------------------------*/

AEC aec; 
Ball q1Ball, q2Ball, q3Ball, q4Ball, sarahq1Ball, kiraq1Ball, sarahq2Ball, kiraq2Ball, sarahq3Ball, kiraq3Ball, sarahq4Ball, kiraq4Ball;

//  int leftX, rightX, topY, bottomY;
//Wall 1
PVector q1tl= new PVector (0, 1);
PVector q1tr= new PVector (9, 1);
PVector q1bl= new PVector (0, 22);
PVector q1br= new PVector (9, 22);

//Wall 2
PVector q2tl= new PVector (10, 1);
PVector q2tr= new PVector (19, 1);
PVector q2bl= new PVector (10, 20);
PVector q2br= new PVector (19, 20);

//Wall 3
PVector q3tl= new PVector (20, 2);
PVector q3tr= new PVector (29, 2);
PVector q3bl= new PVector (20, 21);
PVector q3br= new PVector (29, 21);

//Wall 4
PVector q4tl= new PVector (30, 2);
PVector q4tr= new PVector (39, 2);
PVector q4bl= new PVector (30, 24);
PVector q4br= new PVector (39, 24);

Wall q1 = new Wall(q1tl, q1tr, q1bl, q1br, 2, 3, 1);
Wall q2 = new Wall(q2tl, q2tr, q2bl, q2br, 2, 3, 2);
Wall q3 = new Wall(q3tl, q3tr, q3bl, q3br, 2, 3, 3);
Wall q4 = new Wall(q4tl, q4tr, q4bl, q4br, 2, 3, 4);

public void setup() {
  
  frameRate(5);
  aec = new AEC();
  aec.init();
  PVector q1Position = new PVector(0, 9);
  PVector q2Position = new PVector(10, 1);
  PVector q3Position = new PVector(25, 5); 
  PVector q4Position = new PVector(30, 2);

  int green = color(153, 204, 0);
  int coral = color(255, 153, 102);
  int purple = color(153, 0, 255);
  int teal = color(0, 153, 153);


  //blue
  q1Ball = new Ball(q1Position.x, q1Position.y, 2, 3, 1, q1, green);

  //  sarahq1Ball = new Ball(q1Position.x + 7, q1Position.y + 2, 2, 3, 1, q1, 17, 150, 255);
  //  kiraq1Ball = new Ball(q1Position.x + 2, q1Position.y + 9, 2, 3, 1, q1, 143, 17, 200);

  //light blue
  q2Ball = new Ball(q2Position.x, q2Position.y, 2, 3, 1, q2, coral);

  //  sarahq2Ball = new Ball(q2Position.x + 7, q2Position.y + 2, 2, 3, 1, q2, 17, 150, 255);
  //  kiraq2Ball = new Ball(q2Position.x + 7, q2Position.y + 7, 2, 3, 1, q2, 143, 17, 200);

  //pink
  q3Ball = new Ball(q3Position.x, q3Position.y, 2, 3, 1, q3, purple);

  //  sarahq3Ball = new Ball(q3Position.x + 1, q3Position.y + 8, 2, 3, 1, q3, 17, 150, 255);
  //  kiraq3Ball = new Ball(q3Position.x - 4, q3Position.y + 2, 2, 3, 1, q3, 143, 17, 200);

  //purple
  q4Ball = new Ball(q4Position.x, q4Position.y, 2, 3, 1, q4, teal);

  //  sarahq4Ball = new Ball(q4Position.x + 7, q4Position.y + 2, 2, 3, 1, q4, 17, 150, 255);
  //  kiraq4Ball = new Ball(q4Position.x + 7, q4Position.y + 15, 2, 3, 1, q4, 143, 17, 200);
}


public void draw() {
  aec.beginDraw();
  background(0);

  q1Ball.move();
  q1Ball.render();
  q1Ball.hitCorner();
  q1Ball.addColors();

  //  sarahq1Ball.move();
  //  sarahq1Ball.render();
  //  sarahq1Ball.hitCorner();

  //  kiraq1Ball.move();
  //  kiraq1Ball.render();
  //  kiraq1Ball.hitCorner();

  q2Ball.move();
  q2Ball.render();
  q2Ball.hitCorner();

  //sarahq2Ball.move();
  //sarahq2Ball.render();
  //sarahq2Ball.hitCorner();

  //kiraq2Ball.move();
  //kiraq2Ball.render();
  //kiraq2Ball.hitCorner();

  q3Ball.move();
  q3Ball.render();
  q3Ball.hitCorner();

  //sarahq3Ball.move();
  //sarahq3Ball.render();
  //sarahq3Ball.hitCorner();

  //kiraq3Ball.move();
  //kiraq3Ball.render();
  //kiraq3Ball.hitCorner();


  q4Ball.move();
  q4Ball.render();
  q4Ball.hitCorner();

  //sarahq4Ball.move();
  //sarahq4Ball.render();
  //sarahq4Ball.hitCorner();

  //kiraq4Ball.move();
  //kiraq4Ball.render();
  //kiraq4Ball.hitCorner();

  noStroke();

  //QUADRANT 4 BOUNDS (blue)
  //top left
  fill(0, 153, 153);
  rect(30, 2, 1, 1);

  //top right
  fill(0, 255, 255);
  rect(39, 2, 1, 1);  

  //bottom right 
  fill(102, 255, 255);
  rect(39, 24, 1, 1);

  //bottom left
  fill(204, 255, 255);
  rect(30, 24, 1, 1);

  //QUADRANT 3 BOUNDS (purple)
  //light blue = top left
  fill(153, 0, 255);
  rect(20, 2, 1, 1); 

  //top right
  fill(153, 102, 255);
  rect(29, 2, 1, 1);

  //bottom right 
  fill(204, 204, 255);
  rect(20, 21, 1, 1);

  // bottom left
  fill(153, 153, 255);
  rect(29, 21, 1, 1);

  //QUADRANT 2 BOUNDS (coral)
  //top right
  fill(255, 153, 102);
  rect(19, 1, 1, 1);

  //top left
  fill(255, 80, 80);
  rect(10, 1, 1, 1);  

  //bottom left
  fill(255, 255, 204);
  rect(10, 20, 1, 1);

  //bottom right
  fill(255, 204, 153);

  rect(19, 20, 1, 1);

  //QUADRANT 1 BOUNDS (green)
  //top right
  fill(153, 204, 0);
  rect(9, 1, 1, 1);

  //top left
  fill(102, 153, 0);
  rect(0, 1, 1, 1);  

  //bottom left
  fill(204, 255, 153);
  rect(0, 22, 1, 1);

  //bottom right
  fill(204, 255, 102);
  rect(9, 22, 1, 1);

  aec.endDraw();
  aec.drawSides();
}

public void keyPressed() {
  aec.keyPressed(key);
}




class AEC {
  AECPlugin plugin = new AECPlugin();
  HouseDrawer house = new HouseDrawer(plugin);
  
  public AEC() {
  }

  public void init() {
    plugin.setFrameWidth(width);
    plugin.init();
    loadConfig();
  }
    
  public void loadConfig() {
    plugin.loadConfig();
  }
  
  public void beginDraw() {
    scale(2 * plugin.scale, plugin.scale);
  }
  
  public void endDraw() {
    // reset of the transformation
    resetMatrix();
    
    loadPixels();
    plugin.update(pixels);
  }
  
  public void drawSides() {
    house.draw();
  }
  
  public void keyPressed(int value) {
    plugin.keyPressed(value, keyCode);
    
    if (value == 'i') {
      house.toggleIds();
    }
  }

  public void setActiveColor(Color c) {
    plugin.setActiveColor(c);
  }

  public void setInActiveColor(Color c) {
    plugin.setInActiveColor(c);
  }
  
  public int getScaleX() {
    return 2 * plugin.scale;
  }
  
  public int getScaleY() {
    return plugin.scale;
  }  
}
class Ball {
  float x, y;
  float xVel, yVel;
  Wall wall;
  int currColor;
  int ballWidth;
  int ballHeight;
  float[] stepSize = new float[] {0.5f, 0.25f, 0.125f, 0.0625f};
  int indexX, indexY;
  int[] colors = new int[10];
  boolean cornerCollision = false;
  boolean celeb1done = false;
  int cornerIDHit = 0;
  CelebRect celebrect;

  Ball(float xpos, float ypos, int wid, int hei, float maxVel, Wall w, int c) {
    x = xpos;
    y = ypos;
    ballWidth = wid;
    ballHeight = hei;
    xVel = maxVel;
    yVel = maxVel;
    wall = w;
    currColor = c;

    indexX = PApplet.parseInt(random(stepSize.length));  
    indexY = PApplet.parseInt(random(stepSize.length));  
    this.addColors();

    celebrect = new CelebRect();
  }

  public void addColors() {
    int red = color(255, 0, 0);
    int green = color(57, 181, 16);
    int blue = color(0, 0, 255);
    int orange = color(235, 131, 52);
    int purple = color(158, 52, 235);
    int teal = color(36, 181, 169);
    int white = color(255, 255, 255);
    int coral = color(255, 112, 112);
    int magenta = color(235, 61, 209);
    int yellow = color(255, 224, 66);


    this.colors[0] = red;
    this.colors[1] = green;
    this.colors[2] = blue;
    this.colors[3] = orange;
    this.colors[4] = purple;
    this.colors[5] = teal;
    this.colors[6] = white;
    this.colors[7] = coral;
    this.colors[8] = magenta;
    this.colors[9] = yellow;
  }

  public void render() {
    noStroke();
    fill(this.currColor);
    rect(x, y, ballWidth, ballHeight);

    CelebRect CR = this.celebrect;
    CR.update();
    int celebColor = (colors[PApplet.parseInt(random(0, this.colors.length - 1))]); 
    fill(celebColor);
    rectMode(CORNERS); 

    float ageFraction = (float) CR.age / (float) CR.maxAge;
    //yes
    if (CR.age >= 0) {
      
    if (CR.cornerID == 1) {
      rect(this.wall.getTopL().x, 
        this.wall.getTopL().y, 
        this.wall.getTopL().x + ageFraction *(this.wall.getTopR().x - this.wall.getTopL().x), 
        this.wall.getTopL().y + ageFraction *(this.wall.getBottomL().y - this.wall.getTopL().y));
    }
    ///    
    if (CR.cornerID == 2) {
      rect(this.wall.getTopR().x + 1, 
        this.wall.getTopR().y, 
        this.wall.getTopR().x - ballWidth + ageFraction *(this.wall.getTopL().x - this.wall.getTopR().x), 
        this.wall.getTopR().y + ballHeight + ageFraction *(this.wall.getBottomR().y - this.wall.getTopR().y));
    }
    ///    
    if (CR.cornerID == 3) {
      rect(this.wall.getBottomR().x + 1, 
        this.wall.getBottomR().y + 1, 
        this.wall.getBottomR().x - ballWidth + ageFraction *(this.wall.getBottomL().x - this.wall.getBottomR().x), 
        this.wall.getBottomR().y - ballHeight + ageFraction *(this.wall.getTopR().y - this.wall.getBottomR().y));
    }
    ///
    if (CR.cornerID == 4) {
      rect(this.wall.getBottomL().x, 
        this.wall.getBottomL().y + 1, 
        this.wall.getBottomL().x + ballWidth + ageFraction *(this.wall.getBottomR().x - this.wall.getBottomL().x), 
        this.wall.getBottomL().y - ballHeight + ageFraction *(this.wall.getTopL().y - this.wall.getBottomL().y));
    }
    }
    CR.update();
    // reset the rect mode (not sure if you have to do this)
    rectMode(CORNER);
  }

  public void changeColor() {
    this.currColor = (colors[PApplet.parseInt(random(0, this.colors.length - 1))]); 
    render();
  }

  public void move() {
    x += xVel * stepSize[indexX];
    y += yVel * stepSize[indexY];

    if (x > wall.getTopR().x - stepSize[indexX] - (ballWidth / 2) || x < wall.getTopL().x + stepSize[indexX]) { 
      xVel *= -1;
    }
    if (y > wall.getBottomR().y - (stepSize[indexY] + (ballHeight)) + 1 || y < wall.getTopL().y + stepSize[indexY]) { 
      yVel *= -1;
    }
  }

  public void hitCorner() {
    if (this.x == wall.getTopLBound().x && this.y == wall.getTopLBound().y) {
      changeColor();
      this.cornerCollision = true;
      this.cornerIDHit = 1;

      this.celebration();
    }

    if (this.x == wall.getTopRBound().x && this.y == wall.getTopRBound().y) {
      changeColor();
      this.cornerCollision = true;
      this.cornerIDHit = 2;

      this.celebration();
    }

    if (this.x == wall.getBottomRBound().x && this.y == wall.getBottomRBound().y) {
      changeColor();
      this.cornerCollision = true;
      this.cornerIDHit = 3;

      this.celebration();
    }

    if (this.x == wall.getBottomLBound().x && this.y == wall.getBottomLBound().y) {
      changeColor();
      this.cornerCollision = true;
      this.cornerIDHit = 4;

      this.celebration();
    }
  }

  //CELEBRATION!!!
  public void celebration() {
    fill(this.currColor);
    //rect(this.wall.getTopL().x, this.wall.getTopL().y, 10, 21);
    this.cornerCollision = false;
    this.celeb1done = true;
    this.celeb2();
  }

  public void celeb2() {

    // 1 = tl, 2 = tr, 3 = br, 4 = bl

    //println(wall.id + " wall top r X: " + this.wall.getTopR().x);
    //println(wall.id + " wall top r Y: " + this.wall.getTopR().y);
    //println(wall.id + "wall bottom r X: " + this.wall.getBottomR().x);
    //println(wall.id + "wall bottom r Y: " + this.wall.getBottomR().y);

    //println(wall.id + "wall top L X: " + this.wall.getTopL().x);
    //println(wall.id + "wall top L Y: " + this.wall.getTopL().y);
    //println(wall.id + "wall bottom L X: " + this.wall.getBottomL().x);
    //println(wall.id + "wall bottom L Y: " + this.wall.getBottomL().y);


    if (this.celeb1done == true) {
      // color newColor = (colors[int(random(0, this.colors.length - 1))]);
      fill(255);

      int w = 9/2;
      int h = 19/2;

      this.celebrect.cornerID = this.cornerIDHit;
      this.celebrect.age = 0;

      ////if it hit the top left: 
      //if (this.cornerIDHit == 1) {
      //  // this.celebrect.corner

      //  rect(this.wall.getTopL().x, this.wall.getTopL().y, w, h);
      //  println("painting corner 1 square at: " + this.wall.getTopR().x + "," + this.wall.getTopR().y);
      //}

      ////if it hit the top right ( rect bottom left but off screen) so - height, or minus 9/2
      //if (this.cornerIDHit == 2) {
      //  rect(this.wall.getTopR().x - w, this.wall.getTopR().y, w, h);
      //  println("painting corner 2 square at: " + (this.wall.getTopR().x - w) + "," + this.wall.getTopR().y);
      //}

      ////if it hit the bottmo right
      //if (this.cornerIDHit == 3) {
      //  rect(this.wall.getBottomR().x - w, this.wall.getBottomR().y - h, w, h);
      //  println("painting corner 3 square at: " + (this.wall.getTopR().x - w) + "," + (this.wall.getTopR().y - h));
      //}
      ////if it hit the bottom left
      //if (this.cornerIDHit == 4) {
      //  //rect(this.wall.getTopL().x, this.wall.getTopL().y, 9 / 2, 19 / 2);
      //  rect(this.wall.getBottomL().x, this.wall.getBottomL().y - h, w, h);
      //  println("painting corner 4 square at: " + (this.wall.getTopL().x + "," + (this.wall.getTopL().y - h)));
      //}

      this.celeb1done = false;
      this.cornerIDHit = 0;
    }
  }
}

class CelebRect {
  int age;
  int maxAge;

  int cornerID;

  CelebRect() {
    age = -1;
    maxAge = 100;
  }
  
 //increment age, until certain size, then set back to -1 (inactive)
  public void update() {
    if (age >=0) {
      println("age is: " + age);
      age ++;
    }
    //reset to inactive
    if (age > maxAge) {
      age = -1;
    }
  }
}


class HouseDrawer {
  AECPlugin aec;
  int size = 10;  
  PFont font;
  boolean showIds = false;
  
  public HouseDrawer(AECPlugin aec_) {
    aec = aec_;
    font = loadFont("LucidaConsole-8.vlw"); 
  }
  
  public void toggleIds() {
    showIds = !showIds;
  }
  
  public void draw() {
    resetMatrix();
    
    for (int i = 0; i < Building.SIDE.values().length; ++i) {
      Building.SIDE sideEnum = Building.SIDE.values()[i];
      Side side = aec.getSide(sideEnum);
      
      stroke(side.getColor().getRed(), side.getColor().getGreen(), side.getColor().getBlue(), side.getColor().getAlpha());
      noFill();
      drawSide(side);     
    }
  }
  
  public void drawSide(Side s) {
    int[][] adr = s.getWindowAddress();
    int pWidth = s.getPixelWidth();
    int pHeight = s.getPixelHeight();

    for (int y = 0; y < adr.length; ++y) {
      for (int x = 0; x < adr[y].length; ++x) {
        if (adr[y][x] > -1) {
          int fx = (s.getX() + x * pWidth) * aec.scale;
          int fy = (s.getY() + y * pHeight) * aec.scale;
          rect(fx, fy, pWidth * aec.scale, pHeight * aec.scale);
          
          if (showIds) {
            textFont(font, 8); 
            text("" + adr[y][x], fx + pWidth * aec.scale / 4, fy + pHeight * aec.scale * 0.9f);
          }
        }
      }
    }
  }
}
class Wall {
  PVector  topL, topR, bottomL, bottomR;
  int ballWidth;
  int ballHeight;
  int id;
  
  Wall(PVector tl, PVector tr, PVector bl, PVector br, int bw, int bh, int id_name) {
    topL = tl;
    topR = tr;
    bottomL = bl;
    bottomR = br;
    ballWidth = bw;
    ballHeight = bh;
    id = id_name;
  }

  public PVector getTopL() {
    return this.topL;
  }

  public PVector getTopR() {
    return this.topR;
  }

  public PVector getBottomL() {
    return this.bottomL;
  }

  public PVector getBottomR() {
    return this.bottomR;
  }
  
    public PVector getTopLBound() {
    return this.topL;
  }

  public PVector getTopRBound() {
    return new PVector((this.topR.x - (this.ballWidth / 2)), this.topR.y);
  }

  public PVector getBottomLBound() {
    return new PVector(this.bottomL.x , this.bottomL.y - this.ballWidth);
  }

  public PVector getBottomRBound() {
    return new PVector((this.bottomR.x - (this.ballWidth / 2)), (this.bottomR.y - this.ballWidth));
  }
  
  
}
  public void settings() {  size(1200, 220); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "rarah_v6" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
